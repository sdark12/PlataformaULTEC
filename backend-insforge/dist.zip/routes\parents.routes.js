"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const parents_controller_1 = require("../controllers/parents.controller");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.requireAuth);
// Admin endpoints
router.get('/links', parents_controller_1.getParentLinks);
router.post('/links', parents_controller_1.createParentLink);
router.delete('/links/:id', parents_controller_1.deleteParentLink);
// Parent endpoints
router.get('/my-students', parents_controller_1.getMyStudents);
router.get('/child/:studentId/dashboard', parents_controller_1.getChildDashboard);
router.get('/child/:studentId/payments', parents_controller_1.getChildPayments);
router.get('/child/:studentId/grades', parents_controller_1.getChildGrades);
router.get('/child/:studentId/assignments', parents_controller_1.getChildAssignments);
router.get('/child/:studentId/discipline', parents_controller_1.getChildDiscipline);
exports.default = router;
