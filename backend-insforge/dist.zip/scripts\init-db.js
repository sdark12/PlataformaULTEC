"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const database_1 = __importDefault(require("../config/database"));
async function initDb() {
    const client = await database_1.default.connect();
    try {
        console.log('Starting database initialization...');
        const schemaPath = path_1.default.join(__dirname, '../database/schema.sql');
        const seedPath = path_1.default.join(__dirname, '../database/seed.sql');
        const schemaSql = fs_1.default.readFileSync(schemaPath, 'utf8');
        const seedSql = fs_1.default.readFileSync(seedPath, 'utf8');
        console.log('Applying schema...');
        await client.query('BEGIN');
        await client.query(schemaSql);
        await client.query('COMMIT');
        console.log('Schema applied successfully.');
        console.log('Applying seed data...');
        await client.query('BEGIN');
        await client.query(seedSql);
        await client.query('COMMIT');
        console.log('Seed data applied successfully.');
    }
    catch (err) {
        await client.query('ROLLBACK');
        console.error('Error during database initialization:', err);
        process.exit(1);
    }
    finally {
        client.release();
        await database_1.default.end();
    }
}
initDb();
