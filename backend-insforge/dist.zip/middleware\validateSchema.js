"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validateSchema = void 0;
const zod_1 = require("zod");
const validateSchema = (schema) => (req, res, next) => {
    try {
        schema.parse({
            body: req.body,
            query: req.query,
            params: req.params,
        });
        next();
    }
    catch (error) {
        if (error instanceof zod_1.ZodError || error?.name === 'ZodError') {
            const issues = error.errors || error.issues || [];
            res.status(400).json({
                status: 'error',
                message: 'Validation failed',
                errors: issues.map((err) => ({
                    field: err.path ? err.path.join('.') : 'unknown',
                    message: err.message,
                })),
            });
            return;
        }
        res.status(500).json({
            status: 'error',
            message: 'Internal server error during validation'
        });
        return;
    }
};
exports.validateSchema = validateSchema;
