"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const merits_controller_1 = require("../controllers/merits.controller");
const router = (0, express_1.Router)();
router.use(auth_middleware_1.requireAuth);
// Student merits queries
router.get('/student/:student_id/balance', merits_controller_1.getStudentBalance);
router.get('/leaderboard', merits_controller_1.getLeaderboard);
router.post('/award', merits_controller_1.awardPoints);
// Rewards CRUD and claims
router.get('/rewards', merits_controller_1.getRewards);
router.post('/rewards', merits_controller_1.createReward);
router.put('/rewards/:id', merits_controller_1.updateReward);
router.delete('/rewards/:id', merits_controller_1.deleteReward);
router.post('/rewards/:id/claim', merits_controller_1.claimReward);
exports.default = router;
