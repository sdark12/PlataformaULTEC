"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateUserSchema = exports.createUserSchema = void 0;
const zod_1 = require("zod");
exports.createUserSchema = zod_1.z.object({
    body: zod_1.z.object({
        email: zod_1.z.string().min(5, "El nombre de usuario/correo electrónico es muy corto."),
        password: zod_1.z.string().min(6, "La contraseña debe tener al menos 6 caracteres."),
        full_name: zod_1.z.string().min(3, "El nombre debe tener al menos 3 caracteres."),
        role: zod_1.z.enum(['student', 'instructor', 'secretary', 'admin', 'superadmin']),
        phone: zod_1.z.string().optional(),
        student_id: zod_1.z.string().uuid("ID de estudiante inválido").optional().nullable().or(zod_1.z.literal('')),
        branch_id: zod_1.z.string().uuid("ID de sede inválido").optional().nullable().or(zod_1.z.literal('')),
    }),
});
exports.updateUserSchema = zod_1.z.object({
    body: zod_1.z.object({
        full_name: zod_1.z.string().min(3, "El nombre debe tener al menos 3 caracteres.").optional(),
        email: zod_1.z.string().min(5, "El nombre de usuario/correo electrónico es muy corto.").optional(),
        role: zod_1.z.enum(['student', 'instructor', 'secretary', 'admin', 'superadmin']).optional(),
        phone: zod_1.z.string().optional(),
        active: zod_1.z.boolean().optional(),
        student_id: zod_1.z.string().uuid("ID de estudiante inválido").optional().nullable().or(zod_1.z.literal('')),
        branch_id: zod_1.z.string().uuid("ID de sede inválido").optional().nullable().or(zod_1.z.literal('')),
    }),
});
