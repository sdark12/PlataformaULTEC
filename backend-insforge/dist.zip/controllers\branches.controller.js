"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteBranch = exports.updateBranch = exports.createBranch = exports.getBranches = void 0;
const insforge_1 = __importDefault(require("../config/insforge"));
const getBranches = async (req, res) => {
    const db = req.dbUserClient || insforge_1.default;
    try {
        const { data, error } = await db
            .from('branches')
            .select('*')
            .order('name');
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error('CRITICAL ERROR in getBranches:', error);
        res.status(500).json({
            message: 'Error retrieving branches',
            error: error?.message || 'Unknown error'
        });
    }
};
exports.getBranches = getBranches;
const createBranch = async (req, res) => {
    const { name, address, phone, email } = req.body;
    const db = req.dbUserClient || insforge_1.default;
    try {
        const { data, error } = await db
            .from('branches')
            .insert([{ name, address, phone, email }])
            .select()
            .single();
        if (error)
            throw error;
        res.status(201).json(data);
    }
    catch (error) {
        console.error("Error creating branch:", error);
        let errorMessage = 'Error creating branch';
        if (error.message && error.message.includes('Could not find the \'email\' column')) {
            errorMessage = 'Falta la columna "email" en la base de datos. Por favor, ejecute: ALTER TABLE branches ADD COLUMN email VARCHAR(150);';
        }
        res.status(500).json({ message: errorMessage, error: error.message });
    }
};
exports.createBranch = createBranch;
const updateBranch = async (req, res) => {
    const { id } = req.params;
    const { name, address, phone, email } = req.body;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        const { data, error } = await db
            .from('branches')
            .update({ name, address, phone, email })
            .eq('id', id)
            .select()
            .single();
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error("Error updating branch:", error);
        let errorMessage = 'Error updating branch';
        if (error.message && error.message.includes('Could not find the \'email\' column')) {
            errorMessage = 'Falta la columna "email" en la base de datos. Por favor, ejecute: ALTER TABLE branches ADD COLUMN email VARCHAR(150);';
        }
        res.status(500).json({ message: errorMessage, error: error.message });
    }
};
exports.updateBranch = updateBranch;
const deleteBranch = async (req, res) => {
    const { id } = req.params;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        const { error } = await db
            .from('branches')
            .delete()
            .eq('id', id);
        if (error)
            throw error;
        res.json({ message: 'Branch deleted successfully' });
    }
    catch (error) {
        console.error("Error deleting branch:", error);
        res.status(500).json({ message: 'Error deleting branch', error: error.message });
    }
};
exports.deleteBranch = deleteBranch;
