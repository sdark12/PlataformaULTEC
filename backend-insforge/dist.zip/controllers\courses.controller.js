"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteCourseSchedule = exports.createCourseSchedule = exports.getCourseSchedules = exports.deleteCourse = exports.updateCourse = exports.createCourse = exports.getCourses = void 0;
const insforge_1 = __importDefault(require("../config/insforge"));
const notification_service_1 = require("../services/notification.service");
const getCourses = async (req, res) => {
    const branchId = req.currentUser?.branch_id;
    const db = req.dbUserClient || insforge_1.default;
    try {
        let query = db
            .from('courses')
            .select('*')
            .eq('is_active', true)
            .order('name');
        if (branchId) {
            query = query.eq('branch_id', branchId);
        }
        const { data, error } = await query;
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error('CRITICAL ERROR in getCourses:', error);
        if (error instanceof Error) {
            console.error('Stack:', error.stack);
            console.error('Message:', error.message);
        }
        else {
            console.error('Unknown error object:', JSON.stringify(error));
        }
        res.status(500).json({
            message: 'Error retrieving courses',
            error: error?.message || 'Unknown error',
            details: JSON.stringify(error)
        });
    }
};
exports.getCourses = getCourses;
const createCourse = async (req, res) => {
    const { name, description, monthly_fee, start_date, end_date, branch_id } = req.body;
    // Clean up empty strings to null for database compatibility
    const finalBranchId = (branch_id === '' ? null : branch_id) || req.currentUser?.branch_id;
    const finalStartDate = start_date === '' ? null : start_date;
    const finalEndDate = end_date === '' ? null : end_date;
    const finalDescription = description === '' ? null : description;
    const db = req.dbUserClient || insforge_1.default;
    console.log('createCourse:', { branchId: finalBranchId, bodyName: name });
    try {
        const { data, error } = await db
            .from('courses')
            .insert([{ branch_id: finalBranchId, name, description: finalDescription, monthly_fee, start_date: finalStartDate, end_date: finalEndDate }])
            .select()
            .single();
        if (error)
            throw error;
        res.status(201).json(data);
    }
    catch (error) {
        console.error("Error creating course:", error);
        res.status(500).json({ message: 'Error creating course', error: error.message });
    }
};
exports.createCourse = createCourse;
const updateCourse = async (req, res) => {
    const { id } = req.params;
    const { name, description, monthly_fee, is_active, start_date, end_date } = req.body;
    // Clean up empty strings to null for database compatibility
    const finalStartDate = start_date === '' ? null : start_date;
    const finalEndDate = end_date === '' ? null : end_date;
    const finalDescription = description === '' ? null : description;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    const branchId = req.currentUser?.branch_id;
    try {
        let query = db
            .from('courses')
            .update({ name, description: finalDescription, monthly_fee, is_active, start_date: finalStartDate, end_date: finalEndDate })
            .eq('id', id);
        if (branchId) {
            query = query.eq('branch_id', branchId);
        }
        const { data, error } = await query.select().single();
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error("Error updating course:", error);
        res.status(500).json({ message: 'Error updating course', error: error.message });
    }
};
exports.updateCourse = updateCourse;
const deleteCourse = async (req, res) => {
    const { id } = req.params;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    const branchId = req.currentUser?.branch_id;
    try {
        let query = db
            .from('courses')
            .delete()
            .eq('id', id);
        if (branchId) {
            query = query.eq('branch_id', branchId);
        }
        const { error } = await query;
        if (error)
            throw error;
        if (branchId) {
            await (0, notification_service_1.broadcastNotification)(insforge_1.default, branchId, 'Curso Eliminado', `Se ha eliminado un curso del sistema.`, 'DELETE');
        }
        res.json({ message: 'Course deleted successfully' });
    }
    catch (error) {
        console.error("Error deleting course:", error);
        res.status(500).json({ message: 'Error deleting course', error: error.message });
    }
};
exports.deleteCourse = deleteCourse;
const getCourseSchedules = async (req, res) => {
    const { id } = req.params;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        const { data, error } = await db
            .from('course_schedules')
            .select('*')
            .eq('course_id', id)
            .order('grade');
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error("Error fetching course schedules:", error);
        res.status(500).json({ message: 'Error fetching schedules' });
    }
};
exports.getCourseSchedules = getCourseSchedules;
const createCourseSchedule = async (req, res) => {
    const { id } = req.params;
    const { grade, day_of_week, start_time, end_time } = req.body;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        const { data, error } = await db
            .from('course_schedules')
            .insert([{ course_id: id, grade, day_of_week, start_time, end_time }])
            .select()
            .single();
        if (error)
            throw error;
        res.status(201).json(data);
    }
    catch (error) {
        console.error("Error creating course schedule:", error);
        res.status(500).json({ message: 'Error creating schedule', error: error.message });
    }
};
exports.createCourseSchedule = createCourseSchedule;
const deleteCourseSchedule = async (req, res) => {
    const { scheduleId } = req.params;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        const { error } = await db
            .from('course_schedules')
            .delete()
            .eq('id', scheduleId);
        if (error)
            throw error;
        res.json({ message: 'Schedule deleted successfully' });
    }
    catch (error) {
        console.error("Error deleting course schedule:", error);
        res.status(500).json({ message: 'Error deleting schedule', error: error.message });
    }
};
exports.deleteCourseSchedule = deleteCourseSchedule;
