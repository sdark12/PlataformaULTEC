"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveSubgrades = exports.getSubgrades = exports.deleteSubgradeCategory = exports.saveSubgradeCategories = exports.getSubgradeCategories = void 0;
const insforge_1 = __importDefault(require("../config/insforge"));
const getSubgradeCategories = async (req, res) => {
    const { course_id, unit_name } = req.query;
    if (!course_id || !unit_name) {
        return res.status(400).json({ message: 'course_id and unit_name are required' });
    }
    try {
        const { data: categories, error } = await insforge_1.default
            .from('subgrade_categories')
            .select('*')
            .eq('course_id', course_id)
            .eq('unit_name', unit_name)
            .order('created_at', { ascending: true });
        if (error)
            throw error;
        res.json(categories);
    }
    catch (error) {
        console.error('Error retrieving subgrade categories:', error);
        res.status(500).json({ message: 'Error retrieving subgrade categories' });
    }
};
exports.getSubgradeCategories = getSubgradeCategories;
const saveSubgradeCategories = async (req, res) => {
    const { course_id, unit_name, categories } = req.body;
    const userId = req.currentUser?.id;
    if (!course_id || !unit_name || !Array.isArray(categories)) {
        return res.status(400).json({ message: 'Invalid payload' });
    }
    try {
        const results = [];
        for (const c of categories) {
            if (c.id) {
                // UPDATE existing category
                const { data, error } = await insforge_1.default
                    .from('subgrade_categories')
                    .update({
                    name: c.name,
                    max_score: Number(c.max_score) || 100
                })
                    .eq('id', c.id)
                    .select()
                    .single();
                if (error)
                    throw error;
                results.push(data);
            }
            else {
                // INSERT new category
                const { data, error } = await insforge_1.default
                    .from('subgrade_categories')
                    .insert({
                    course_id,
                    unit_name,
                    name: c.name,
                    max_score: Number(c.max_score) || 100,
                    created_by: userId
                })
                    .select()
                    .single();
                if (error)
                    throw error;
                results.push(data);
            }
        }
        res.json({ message: 'Categories saved successfully', categories: results });
    }
    catch (error) {
        console.error('Error saving subgrade categories:', error);
        res.status(500).json({ message: 'Error saving subgrade categories' });
    }
};
exports.saveSubgradeCategories = saveSubgradeCategories;
const deleteSubgradeCategory = async (req, res) => {
    const { category_id } = req.params;
    try {
        const { error } = await insforge_1.default
            .from('subgrade_categories')
            .delete()
            .eq('id', category_id);
        if (error)
            throw error;
        res.json({ message: 'Category deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting subgrade category:', error);
        res.status(500).json({ message: 'Error deleting subgrade category' });
    }
};
exports.deleteSubgradeCategory = deleteSubgradeCategory;
const getSubgrades = async (req, res) => {
    const { course_id, unit_name } = req.query;
    const branchId = req.currentUser?.branch_id;
    if (!course_id || !unit_name) {
        return res.status(400).json({ message: 'course_id and unit_name are required' });
    }
    try {
        // 1. Fetch Categories
        const { data: categories, error: catError } = await insforge_1.default
            .from('subgrade_categories')
            .select('id, name, max_score')
            .eq('course_id', course_id)
            .eq('unit_name', unit_name);
        if (catError)
            throw catError;
        // 2. Fetch Enrolled Students
        let enrollmentsQuery = insforge_1.default
            .from('enrollments')
            .select(`
                student_id,
                students!inner (
                    id,
                    full_name,
                    branch_id
                )
            `)
            .eq('course_id', course_id)
            .eq('is_active', true);
        if (branchId) {
            enrollmentsQuery = enrollmentsQuery.eq('students.branch_id', branchId);
        }
        const { data: enrollments, error: enrollError } = await enrollmentsQuery;
        if (enrollError)
            throw enrollError;
        // 3. Fetch Subgrades for these categories
        let subgradesData = [];
        if (categories && categories.length > 0) {
            const categoryIds = categories.map((c) => c.id);
            const { data: sgData, error: sgError } = await insforge_1.default
                .from('subgrades')
                .select('category_id, student_id, score, remarks')
                .in('category_id', categoryIds);
            if (sgError)
                throw sgError;
            subgradesData = sgData || [];
        }
        // 4. Merge into tabular format
        const responseData = enrollments?.map((enrollment) => {
            const studentId = enrollment.student_id;
            const studentName = enrollment.students.full_name;
            const scores = {};
            // Initialize empty scores for all categories
            categories?.forEach((cat) => {
                scores[cat.id] = { score: '', remarks: '' };
            });
            // Fill actual scores
            subgradesData.forEach((sg) => {
                if (sg.student_id === studentId && scores[sg.category_id]) {
                    scores[sg.category_id] = { score: sg.score, remarks: sg.remarks };
                }
            });
            return {
                student_id: studentId,
                student_name: studentName,
                scores
            };
        }) || [];
        responseData.sort((a, b) => a.student_name.localeCompare(b.student_name));
        res.json({ categories, students: responseData });
    }
    catch (error) {
        console.error('Error retrieving subgrades:', error);
        res.status(500).json({ message: 'Error retrieving subgrades' });
    }
};
exports.getSubgrades = getSubgrades;
const saveSubgrades = async (req, res) => {
    // Array of { category_id, student_id, score, remarks }
    const { subgrades } = req.body;
    const userId = req.currentUser?.id;
    if (!Array.isArray(subgrades)) {
        return res.status(400).json({ message: 'subgrades array is required' });
    }
    try {
        const payload = subgrades.map(sg => ({
            category_id: sg.category_id,
            student_id: sg.student_id,
            score: Number(sg.score) || 0,
            remarks: sg.remarks,
            created_by: userId
        }));
        const { error } = await insforge_1.default
            .from('subgrades')
            .upsert(payload, { onConflict: 'category_id, student_id' });
        if (error)
            throw error;
        res.json({ message: 'Subgrades saved successfully' });
    }
    catch (error) {
        console.error('Error saving subgrades:', error);
        res.status(500).json({ message: 'Error saving subgrades' });
    }
};
exports.saveSubgrades = saveSubgrades;
