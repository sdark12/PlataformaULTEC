"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCourseGradebook = exports.getStudentReportCard = exports.saveGrades = exports.getGrades = void 0;
const insforge_1 = __importStar(require("../config/insforge"));
const settings_controller_1 = require("./settings.controller");
const getGrades = async (req, res) => {
    const { course_id, unit_name, schedule_id } = req.query;
    const branchId = req.currentUser?.branch_id;
    if (!course_id || !unit_name) {
        return res.status(400).json({ message: 'course_id and unit_name are required' });
    }
    try {
        // 1. Fetch all active enrolled students
        let enrollmentsQuery = insforge_1.default
            .from('enrollments')
            .select(`
                student_id,
                schedule_id,
                students!inner (
                    id,
                    full_name,
                    branch_id
                )
            `)
            .eq('course_id', course_id)
            .eq('is_active', true);
        if (branchId) {
            enrollmentsQuery = enrollmentsQuery.eq('students.branch_id', branchId);
        }
        if (schedule_id) {
            enrollmentsQuery = enrollmentsQuery.eq('schedule_id', schedule_id);
        }
        const { data: enrollments, error: enrollError } = await enrollmentsQuery;
        if (enrollError)
            throw enrollError;
        // 2. Fetch existing grades
        const { data: gradesData, error: gradesError } = await insforge_1.default
            .from('grades')
            .select('student_id, score, remarks')
            .eq('course_id', course_id)
            .eq('unit_name', unit_name);
        if (gradesError)
            throw gradesError;
        // Map for quick lookup
        const gradesMap = new Map();
        if (gradesData) {
            gradesData.forEach((record) => {
                gradesMap.set(record.student_id, record);
            });
        }
        // 3. Merge data
        const mergedData = enrollments?.map((enrollment) => {
            const studentId = enrollment.student_id;
            const existingRecord = gradesMap.get(studentId);
            return {
                student_id: studentId,
                student_name: enrollment.students.full_name,
                unit_name: unit_name,
                score: existingRecord ? existingRecord.score : '',
                remarks: existingRecord ? existingRecord.remarks : ''
            };
        }) || [];
        // Sort alphabetically
        mergedData.sort((a, b) => a.student_name.localeCompare(b.student_name));
        res.json(mergedData);
    }
    catch (error) {
        console.error('Error retrieving grades:', error);
        res.status(500).json({ message: 'Error retrieving grades' });
    }
};
exports.getGrades = getGrades;
// Helper: Handle automatic merit allocation for excellent/good grades
const handleGradeMerits = async (records, creatorUserId) => {
    try {
        const autoEnabled = await (0, settings_controller_1.getSettingBool)('merit_enable_auto_grades');
        if (!autoEnabled)
            return;
        const pointsExcellent = await (0, settings_controller_1.getSettingNumber)('merit_points_grade_excellent');
        const pointsGood = await (0, settings_controller_1.getSettingNumber)('merit_points_grade_good');
        for (const r of records) {
            const score = Number(r.score);
            let pointsAwarded = 0;
            let levelLabel = '';
            if (score >= 90) {
                pointsAwarded = pointsExcellent;
                levelLabel = 'Excelente';
            }
            else if (score >= 80) {
                pointsAwarded = pointsGood;
                levelLabel = 'Bueno';
            }
            if (pointsAwarded > 0) {
                // Upsert merit transaction
                await insforge_1.adminClient
                    .from('merit_transactions')
                    .upsert({
                    student_id: r.student_id,
                    points: pointsAwarded,
                    transaction_type: 'grade',
                    description: `Nota Sobresaliente (${levelLabel}: ${score} pts) - Unidad: ${r.unit_name}`,
                    reference_id: r.id,
                    created_by: creatorUserId || null
                }, { onConflict: 'student_id, reference_id, transaction_type' });
            }
            else {
                // Delete transaction if score is below 80 but previously got points
                await insforge_1.adminClient
                    .from('merit_transactions')
                    .delete()
                    .eq('student_id', r.student_id)
                    .eq('reference_id', r.id)
                    .eq('transaction_type', 'grade');
            }
        }
    }
    catch (err) {
        console.error('Error handling grade merits:', err);
    }
};
const saveGrades = async (req, res) => {
    const { course_id, unit_name, students } = req.body;
    const userId = req.currentUser?.id;
    if (!course_id || !unit_name || !students) {
        return res.status(400).json({ message: 'Missing required fields' });
    }
    try {
        const upsertData = students.map((s) => ({
            course_id,
            student_id: s.student_id,
            unit_name,
            score: Number(s.score) || 0,
            remarks: s.remarks,
            created_by: userId
        }));
        const { data, error } = await insforge_1.default
            .from('grades')
            .upsert(upsertData, { onConflict: 'course_id, student_id, unit_name' })
            .select('id, student_id, score, unit_name');
        if (error)
            throw error;
        // Process automatic grade merits in background
        if (data && data.length > 0) {
            handleGradeMerits(data, userId).catch(err => console.error('Failed to trigger background grade merits:', err));
        }
        res.json({ message: 'Grades saved successfully' });
    }
    catch (error) {
        console.error('Error saving grades:', error);
        res.status(500).json({ message: 'Error saving grades' });
    }
};
exports.saveGrades = saveGrades;
/**
 * Helper: Calculate how many grade units a student can see per course
 * based on their tuition payment status.
 *
 * Logic:
 *  - For each enrollment, determine months elapsed since course start.
 *  - Determine months actually paid (TUITION payments).
 *  - 4 units spread across the total course duration (default 11 months).
 *  - Allowed units = floor(monthsPaid / monthsPerUnit), capped at total units (4).
 *  - If fully paid (no pending), show all.
 *  - Returns a Map<courseId, number> with max allowed units per course.
 */
const calculateAllowedUnits = async (studentId, courseIds) => {
    const allowedMap = new Map();
    const TOTAL_UNITS = 4;
    if (courseIds.length === 0)
        return allowedMap;
    // Get enrollments for these courses
    const { data: enrollments } = await insforge_1.adminClient
        .from('enrollments')
        .select('id, course_id, enrollment_date, courses (monthly_fee, duration_months, start_date)')
        .eq('student_id', studentId)
        .eq('is_active', true)
        .in('course_id', courseIds);
    if (!enrollments || enrollments.length === 0) {
        // No enrollments found — allow all by default
        courseIds.forEach(cid => allowedMap.set(cid, TOTAL_UNITS));
        return allowedMap;
    }
    const enrollmentIds = enrollments.map((e) => e.id);
    // Get TUITION payments for these enrollments
    const { data: payments } = await insforge_1.adminClient
        .from('payments')
        .select('enrollment_id, amount, discount')
        .in('enrollment_id', enrollmentIds)
        .eq('payment_type', 'TUITION');
    // Sum paid per enrollment
    const paidPerEnrollment = {};
    payments?.forEach((p) => {
        const key = String(p.enrollment_id);
        paidPerEnrollment[key] = (paidPerEnrollment[key] || 0) + Number(p.amount || 0) + Number(p.discount || 0);
    });
    const currentDate = new Date();
    const cutoffsStr = await (0, settings_controller_1.getSetting)('grade_unit_cutoff_months');
    const cutoffs = cutoffsStr.split(',').map(n => Number(n)).filter(n => !isNaN(n));
    enrollments.forEach((enrollment) => {
        const monthlyFee = Number(enrollment.courses?.monthly_fee || 0);
        const durationMonths = enrollment.courses?.duration_months || 11;
        const baseDate = enrollment.courses?.start_date
            ? new Date(enrollment.courses.start_date)
            : new Date(enrollment.enrollment_date);
        // Months elapsed since course start
        let monthsElapsed = 0;
        if (currentDate > baseDate) {
            const yearsDiff = currentDate.getFullYear() - baseDate.getFullYear();
            const monthsDiff = currentDate.getMonth() - baseDate.getMonth();
            monthsElapsed = (yearsDiff * 12) + monthsDiff + 1;
        }
        else {
            monthsElapsed = 1;
        }
        const effectiveMonths = Math.min(monthsElapsed, durationMonths);
        // Total due vs total paid
        const totalDue = effectiveMonths * monthlyFee;
        const totalPaid = paidPerEnrollment[String(enrollment.id)] || 0;
        const monthsCovered = monthlyFee > 0 ? Math.floor(totalPaid / monthlyFee) : durationMonths;
        if (monthlyFee === 0) {
            // Free course → show all units
            allowedMap.set(enrollment.course_id, TOTAL_UNITS);
        }
        else if (cutoffs.length > 0) {
            // Use cutoff thresholds to determine visibility
            let unitsAllowed = 0;
            for (let i = 0; i < cutoffs.length; i++) {
                if (monthsCovered >= cutoffs[i]) {
                    unitsAllowed = i + 1;
                }
                else {
                    break;
                }
            }
            allowedMap.set(enrollment.course_id, Math.min(Math.max(unitsAllowed, 0), TOTAL_UNITS));
        }
        else {
            // No cutoffs configured — use proportional fallback
            if (totalPaid >= totalDue) {
                allowedMap.set(enrollment.course_id, TOTAL_UNITS);
            }
            else {
                const monthsPerUnit = durationMonths / TOTAL_UNITS;
                const unitsAllowed = Math.floor(monthsCovered / monthsPerUnit);
                allowedMap.set(enrollment.course_id, Math.min(Math.max(unitsAllowed, 0), TOTAL_UNITS));
            }
        }
    });
    return allowedMap;
};
const getStudentReportCard = async (req, res) => {
    let { student_id } = req.params;
    const callerRole = req.currentUser?.role;
    try {
        let studentQuery = insforge_1.adminClient
            .from('students')
            .select('full_name, id, user_id');
        const { data: studentRecord, error: findError } = await studentQuery
            .or(`id.eq.${student_id},user_id.eq.${student_id}`)
            .maybeSingle();
        if (findError)
            throw findError;
        if (!studentRecord) {
            return res.status(404).json({ message: 'Estudiante no encontrado' });
        }
        const actualStudentId = studentRecord.id;
        // Get all grades across courses
        const { data: gradesData, error: gradesError } = await insforge_1.adminClient
            .from('grades')
            .select(`
                 score,
                 unit_name,
                 remarks,
                 courses (id, name)
             `)
            .eq('student_id', actualStudentId);
        if (gradesError)
            throw gradesError;
        // Group grades by course
        const coursesMap = new Map();
        gradesData?.forEach((g) => {
            const courseId = g.courses?.id;
            const courseName = g.courses?.name;
            if (!courseId)
                return;
            if (!coursesMap.has(courseId)) {
                coursesMap.set(courseId, {
                    course_id: courseId,
                    course_name: courseName,
                    units: [],
                    average: 0
                });
            }
            coursesMap.get(courseId).units.push({
                unit_name: g.unit_name,
                score: g.score,
                remarks: g.remarks
            });
        });
        // If caller is admin/superadmin/instructor, skip payment restriction
        const isStaff = callerRole && ['admin', 'superadmin', 'instructor'].includes(callerRole);
        const restrictByPayment = await (0, settings_controller_1.getSettingBool)('restrict_grades_by_payment');
        // Calculate payment-based restrictions for students/parents
        let allowedUnitsMap = new Map();
        if (!isStaff && restrictByPayment) {
            const courseIds = Array.from(coursesMap.keys());
            allowedUnitsMap = await calculateAllowedUnits(actualStudentId, courseIds);
        }
        // Sort units by name (Unidad 1, Unidad 2...) and apply restriction
        const unitOrder = ['Unidad 1', 'Unidad 2', 'Unidad 3', 'Unidad 4', 'Examen Final', 'Proyecto'];
        const reportCard = [];
        let totalScoreSum = 0;
        let totalUnits = 0;
        coursesMap.forEach((course) => {
            // Sort units in order
            course.units.sort((a, b) => {
                const ai = unitOrder.indexOf(a.unit_name);
                const bi = unitOrder.indexOf(b.unit_name);
                return (ai === -1 ? 999 : ai) - (bi === -1 ? 999 : bi);
            });
            const allowedCount = isStaff ? course.units.length : (allowedUnitsMap.get(course.course_id) ?? course.units.length);
            let paymentRestricted = false;
            // Apply restriction: mark units beyond allowed as restricted
            const processedUnits = course.units.map((unit, idx) => {
                if (!isStaff && idx >= allowedCount) {
                    paymentRestricted = true;
                    return {
                        unit_name: unit.unit_name,
                        score: null,
                        remarks: null,
                        restricted: true
                    };
                }
                return { ...unit, restricted: false };
            });
            // Only count visible units for average
            const visibleUnits = processedUnits.filter((u) => !u.restricted && u.score !== null);
            const sum = visibleUnits.reduce((acc, curr) => acc + Number(curr.score), 0);
            course.average = visibleUnits.length > 0 ? Number((sum / visibleUnits.length).toFixed(2)) : 0;
            totalScoreSum += sum;
            totalUnits += visibleUnits.length;
            reportCard.push({
                course_name: course.course_name,
                units: processedUnits,
                average: course.average,
                payment_restricted: paymentRestricted
            });
        });
        const generalAverage = totalUnits > 0 ? Number((totalScoreSum / totalUnits).toFixed(2)) : 0;
        res.json({
            student: studentRecord,
            general_average: generalAverage,
            courses: reportCard
        });
    }
    catch (error) {
        console.error('Error retrieving report card:', error);
        res.status(500).json({ message: 'Error retrieving report card' });
    }
};
exports.getStudentReportCard = getStudentReportCard;
const getCourseGradebook = async (req, res) => {
    const { course_id } = req.params;
    const { schedule_id } = req.query;
    const branchId = req.currentUser?.branch_id;
    try {
        // 1. Fetch course details
        const { data: course, error: courseError } = await insforge_1.default
            .from('courses')
            .select('name')
            .eq('id', course_id)
            .single();
        if (courseError)
            throw courseError;
        // 2. Fetch all enrolled students
        let enrollmentsQuery = insforge_1.default
            .from('enrollments')
            .select(`
                student_id,
                schedule_id,
                students!inner (
                    id,
                    full_name,
                    branch_id
                )
            `)
            .eq('course_id', course_id)
            .eq('is_active', true);
        if (branchId) {
            enrollmentsQuery = enrollmentsQuery.eq('students.branch_id', branchId);
        }
        if (schedule_id) {
            enrollmentsQuery = enrollmentsQuery.eq('schedule_id', schedule_id);
        }
        const { data: enrollments, error: enrollError } = await enrollmentsQuery;
        if (enrollError)
            throw enrollError;
        // 3. Fetch all grades for this course
        const { data: gradesData, error: gradesError } = await insforge_1.default
            .from('grades')
            .select('student_id, unit_name, score, remarks')
            .eq('course_id', course_id);
        if (gradesError)
            throw gradesError;
        // 4. Organize grades by student
        const studentGradesMap = new Map();
        // Initialize map with enrolled students
        enrollments?.forEach((e) => {
            studentGradesMap.set(e.student_id, {
                student_id: e.student_id,
                student_name: e.students.full_name,
                units: {},
                average: 0
            });
        });
        // Populate grades
        const allUnitsSet = new Set(); // Keep track of all units ever graded in this course
        gradesData?.forEach((g) => {
            if (studentGradesMap.has(g.student_id)) {
                const studentRecord = studentGradesMap.get(g.student_id);
                studentRecord.units[g.unit_name] = {
                    score: g.score,
                    remarks: g.remarks
                };
                allUnitsSet.add(g.unit_name);
            }
        });
        const allUnits = Array.from(allUnitsSet).sort();
        // Calculate averages for each student
        const gradebook = [];
        studentGradesMap.forEach((student) => {
            let sum = 0;
            let count = 0;
            Object.keys(student.units).forEach(unitName => {
                sum += student.units[unitName].score;
                count++;
            });
            student.average = count > 0 ? (sum / count).toFixed(2) : 0;
            gradebook.push(student);
        });
        // Sort alphabetically
        gradebook.sort((a, b) => a.student_name.localeCompare(b.student_name));
        res.json({
            course_name: course.name,
            units: allUnits,
            students: gradebook
        });
    }
    catch (error) {
        console.error('Error retrieving course gradebook:', error);
        res.status(500).json({ message: 'Error retrieving course gradebook' });
    }
};
exports.getCourseGradebook = getCourseGradebook;
