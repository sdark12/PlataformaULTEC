"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.broadcastNotification = exports.createNotification = void 0;
/**
 * Creates a notification for a specific user.
 * @param dbClient The InsForge SDK client (usually req.dbUserClient or general client)
 * @param userId The recipient's profile UUID
 * @param title The notification title
 * @param message The notification message
 * @param type The type of the notification
 */
const createNotification = async (dbClient, userId, title, message, type) => {
    try {
        const { error } = await dbClient
            .from('notifications')
            .insert([{
                user_id: userId,
                title,
                message,
                type,
                is_read: false
            }]);
        if (error) {
            console.error('Failed to insert notification into DB:', error);
        }
    }
    catch (err) {
        console.error('Error creating notification:', err);
    }
};
exports.createNotification = createNotification;
/**
 * Broadcasts a notification to all users in a specific branch with a specific role.
 * By default, broadcasts to all 'admin' users in the branch.
 */
const broadcastNotification = async (dbClient, branchId, title, message, type, role = 'admin') => {
    try {
        // Find all admins in the branch
        const { data: profiles, error: profileError } = await dbClient
            .from('profiles')
            .select('id')
            .eq('branch_id', branchId)
            .eq('role', role);
        if (profileError || !profiles) {
            console.error('Failed to fetch profiles for broadcast:', profileError);
            return;
        }
        // Insert notifications
        const notificationsToInsert = profiles.map((p) => ({
            user_id: p.id,
            title,
            message,
            type,
            is_read: false
        }));
        if (notificationsToInsert.length > 0) {
            const { error: insertError } = await dbClient
                .from('notifications')
                .insert(notificationsToInsert);
            if (insertError) {
                console.error('Failed to broadcast notifications:', insertError);
            }
        }
    }
    catch (err) {
        console.error('Error broadcasting notification:', err);
    }
};
exports.broadcastNotification = broadcastNotification;
