"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
dotenv_1.default.config();
const auth_routes_1 = __importDefault(require("./routes/auth.routes"));
const audit_middleware_1 = require("./middleware/audit.middleware");
const rateLimiter_1 = require("./middleware/rateLimiter");
const academic_routes_1 = __importDefault(require("./routes/academic.routes"));
const payments_routes_1 = __importDefault(require("./routes/payments.routes"));
const invoices_routes_1 = __importDefault(require("./routes/invoices.routes"));
const attendance_routes_1 = __importDefault(require("./routes/attendance.routes"));
const reports_routes_1 = __importDefault(require("./routes/reports.routes"));
const grades_routes_1 = __importDefault(require("./routes/grades.routes"));
const subgrades_routes_1 = __importDefault(require("./routes/subgrades.routes"));
const notifications_routes_1 = __importDefault(require("./routes/notifications.routes"));
const users_routes_1 = __importDefault(require("./routes/users.routes"));
const assignments_routes_1 = __importDefault(require("./routes/assignments.routes"));
const branches_routes_1 = __importDefault(require("./routes/branches.routes"));
const audit_routes_1 = __importDefault(require("./routes/audit.routes"));
const resources_routes_1 = __importDefault(require("./routes/resources.routes"));
const announcements_routes_1 = __importDefault(require("./routes/announcements.routes"));
const parents_routes_1 = __importDefault(require("./routes/parents.routes"));
const discipline_routes_1 = __importDefault(require("./routes/discipline.routes"));
const settings_routes_1 = __importDefault(require("./routes/settings.routes"));
const merits_routes_1 = __importDefault(require("./routes/merits.routes"));
const app = (0, express_1.default)();
// Trust proxy - required for Render/Vercel reverse proxy
app.set('trust proxy', 1);
// CORS must be configured BEFORE helmet to avoid header conflicts
app.use((0, cors_1.default)({
    origin: function (origin, callback) {
        callback(null, true); // Allow all origins dynamically
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Origin', 'Accept', 'X-Requested-With']
}));
// Security - configure helmet to not interfere with CORS
app.use((0, helmet_1.default)({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    crossOriginOpenerPolicy: { policy: 'unsafe-none' },
    crossOriginEmbedderPolicy: false
}));
app.use(express_1.default.json());
app.use((0, morgan_1.default)('dev'));
// Static files
app.use('/uploads', express_1.default.static(path_1.default.join(__dirname, '../uploads')));
// Global API protection
app.use('/api', rateLimiter_1.apiRateLimiter);
app.use('/api', audit_middleware_1.auditLogger);
// Auth routes (have their own rate limiter)
app.use('/auth', auth_routes_1.default);
// API routes
app.use('/api', academic_routes_1.default);
app.use('/api', payments_routes_1.default);
app.use('/api', invoices_routes_1.default);
app.use('/api', attendance_routes_1.default);
app.use('/api', reports_routes_1.default);
app.use('/api', grades_routes_1.default);
app.use('/api', subgrades_routes_1.default);
app.use('/api', notifications_routes_1.default);
app.use('/api/users', users_routes_1.default);
app.use('/api/assignments', assignments_routes_1.default);
app.use('/api/branches', branches_routes_1.default);
app.use('/api/audit-logs', audit_routes_1.default);
app.use('/api/resources', resources_routes_1.default);
app.use('/api/announcements', announcements_routes_1.default);
app.use('/api/parents', parents_routes_1.default);
app.use('/api/discipline', discipline_routes_1.default);
app.use('/api/settings', settings_routes_1.default);
app.use('/api/merits', merits_routes_1.default);
// Root route
app.get('/', (_req, res) => {
    res.status(200).json({ status: 'ok', service: 'PlataformaULTEC Backend', timestamp: new Date().toISOString() });
});
// Health Check
app.get('/health', (_req, res) => {
    res.status(200).json({ status: 'ok', timestamp: new Date().toISOString() });
});
// Global Error Handler
app.use((err, req, res, next) => {
    console.error('Unhandled Server Error:', err);
    res.status(err.status || err.statusCode || 500).json({
        status: 'error',
        message: err.message || 'Internal server error',
        errors: err.errors || undefined
    });
});
exports.default = app;
