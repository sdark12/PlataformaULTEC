"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteStudent = exports.updateStudent = exports.createStudent = exports.getStudents = void 0;
const insforge_1 = __importDefault(require("../config/insforge"));
const notification_service_1 = require("../services/notification.service");
const supabase_js_1 = require("@supabase/supabase-js");
const email_service_1 = require("../services/email.service");
const linkOrCreateParent = async (studentId, email, fullName, relationship, createdBy) => {
    try {
        const { data: existingProfile } = await insforge_1.default
            .from('profiles')
            .select('id')
            .eq('email', email)
            .single();
        let parentUserId;
        if (existingProfile) {
            parentUserId = existingProfile.id;
        }
        else {
            const tempClient = (0, supabase_js_1.createClient)(process.env.INSFORGE_URL || 'https://w6x267sp.us-east.insforge.app', process.env.INSFORGE_API_KEY || process.env.INSFORGE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3OC0xMjM0LTU2NzgtOTBhYi1jZGVmMTIzNDU2NzgiLCJlbWFpbCI6ImFub25AaW5zZm9yZ2UuY29tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAxOTQ2NTJ9.LsB4ffiFE5H7qEfhgnM0NuPTX_It2aYd4iEmVUOHmh4');
            const password = 'Padre' + Math.floor(1000 + Math.random() * 9000) + '!';
            const { data: authData, error: authError } = await tempClient.auth.signUp({ email, password });
            if (authError || !authData?.user) {
                console.error('Failed to auto-create parent user auth:', authError);
                return;
            }
            parentUserId = authData.user.id;
            const { error: profileError } = await insforge_1.default
                .from('profiles')
                .upsert({
                id: parentUserId,
                email,
                full_name: fullName || 'Encargado',
                role: 'parent',
                active: true
            });
            if (profileError) {
                console.error('Failed to auto-create parent profile:', profileError);
                return;
            }
            (0, email_service_1.sendWelcomeEmail)(email, fullName || 'Encargado', 'parent', password);
        }
        const { data: existingLink } = await insforge_1.default
            .from('parent_student_links')
            .select('id')
            .eq('parent_user_id', parentUserId)
            .eq('student_id', studentId)
            .maybeSingle();
        if (!existingLink) {
            await insforge_1.default
                .from('parent_student_links')
                .insert({
                parent_user_id: parentUserId,
                student_id: studentId,
                relationship: relationship || 'parent',
                created_by: createdBy
            });
        }
    }
    catch (err) {
        console.error('Error linking or creating parent:', err);
    }
};
const getStudents = async (req, res) => {
    const branchId = req.currentUser?.branch_id;
    const db = req.dbUserClient || insforge_1.default;
    try {
        let query = db
            .from('students')
            .select('*', { count: 'exact' })
            .order('full_name');
        if (branchId) {
            query = query.eq('branch_id', branchId);
        }
        const { page, limit, search } = req.query;
        if (search) {
            // Unir varios campos en una búsqueda general o limitar a full_name
            query = query.or(`full_name.ilike.%${search}%,personal_code.ilike.%${search}%`);
        }
        if (page && limit) {
            const pageNum = parseInt(page, 10);
            const limitNum = parseInt(limit, 10);
            const offset = (pageNum - 1) * limitNum;
            query = query.range(offset, offset + limitNum - 1);
            const { data, error, count } = await query;
            if (error)
                throw error;
            return res.json({
                data,
                meta: {
                    total: count || 0,
                    page: pageNum,
                    limit: limitNum,
                    totalPages: Math.ceil((count || 0) / limitNum)
                }
            });
        }
        const { data, error } = await query;
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error('CRITICAL ERROR in getStudents:', error);
        if (error instanceof Error) {
            console.error('Stack:', error.stack);
            console.error('Message:', error.message);
        }
        else {
            console.error('Unknown error object:', JSON.stringify(error));
        }
        res.status(500).json({
            message: 'Error retrieving students',
            error: error?.message || 'Unknown error',
            details: JSON.stringify(error)
        });
    }
};
exports.getStudents = getStudents;
const createStudent = async (req, res) => {
    const { full_name, birth_date, gender, identification_document, nationality, address, phone, 
    // additional_phone, // Check if column exists or add to schema if needed
    guardian_name, guardian_phone, guardian_email, guardian_relationship, emergency_contact_name, emergency_contact_phone, medical_notes, previous_school, personal_code, user_id, // Check for user link
    branch_id // Front-end passed branch_id
     } = req.body;
    // Clean up empty strings to null for database compatibility
    const finalBranchId = (branch_id === '' ? null : branch_id) || req.currentUser?.branch_id;
    const finalBirthDate = birth_date === '' ? null : birth_date;
    const finalUserId = user_id === '' ? null : user_id;
    const db = req.dbUserClient || insforge_1.default;
    console.log('createStudent:', { branchId: finalBranchId, bodyName: full_name });
    try {
        const { data, error } = await db
            .from('students')
            .insert([{
                branch_id: finalBranchId,
                full_name,
                birth_date: finalBirthDate,
                gender,
                identification_document,
                nationality,
                address,
                phone,
                guardian_name,
                guardian_phone,
                guardian_email,
                guardian_relationship,
                emergency_contact_name,
                emergency_contact_phone,
                medical_notes,
                previous_school,
                personal_code,
                user_id: finalUserId
            }])
            .select()
            .single();
        if (error)
            throw error;
        // Auto-create/link parent if email is provided
        if (guardian_email && data?.id) {
            await linkOrCreateParent(data.id, guardian_email.trim(), guardian_name, guardian_relationship, req.currentUser?.id);
        }
        res.status(201).json(data);
    }
    catch (error) {
        console.error("Error creating student:", error);
        res.status(500).json({ message: 'Error creating student', error: error.message });
    }
};
exports.createStudent = createStudent;
const updateStudent = async (req, res) => {
    const { id } = req.params;
    const updates = req.body;
    // Convert empty string to null for UUID and Date columns
    if (updates.user_id === '') {
        updates.user_id = null;
    }
    if (updates.branch_id === '') {
        updates.branch_id = null;
    }
    if (updates.birth_date === '') {
        updates.birth_date = null;
    }
    const branchId = req.currentUser?.branch_id;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        let query = db
            .from('students')
            .update(updates)
            .eq('id', id);
        if (branchId) {
            query = query.eq('branch_id', branchId); // Ensure user can only update students in their branch
        }
        const { data, error } = await query.select().single();
        if (error)
            throw error;
        // Auto-create/link parent if email is provided and updated
        if (updates.guardian_email && updates.guardian_name && data?.id) {
            await linkOrCreateParent(data.id, updates.guardian_email.trim(), updates.guardian_name, updates.guardian_relationship, req.currentUser?.id);
        }
        res.json(data);
    }
    catch (error) {
        console.error("Error updating student:", error);
        res.status(500).json({ message: 'Error updating student', error: error.message });
    }
};
exports.updateStudent = updateStudent;
const deleteStudent = async (req, res) => {
    const { id } = req.params;
    const branchId = req.currentUser?.branch_id;
    const db = req.dbUserClient ? req.dbUserClient : insforge_1.default;
    try {
        let query = db
            .from('students')
            .delete()
            .eq('id', id);
        if (branchId) {
            query = query.eq('branch_id', branchId);
        }
        const { error } = await query;
        if (error)
            throw error;
        if (branchId) {
            await (0, notification_service_1.broadcastNotification)(insforge_1.default, branchId, 'Estudiante Eliminado', `Se ha eliminado un estudiante del sistema.`, 'DELETE');
        }
        res.json({ message: 'Student deleted successfully' });
    }
    catch (error) {
        console.error("Error deleting student:", error);
        res.status(500).json({ message: 'Error deleting student', error: error.message });
    }
};
exports.deleteStudent = deleteStudent;
