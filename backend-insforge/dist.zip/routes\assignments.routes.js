"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const assignments_controller_1 = require("../controllers/assignments.controller");
const auth_middleware_1 = require("../middleware/auth.middleware");
const router = (0, express_1.Router)();
// Add authentication middleware
router.use(auth_middleware_1.requireAuth);
// --- Instructor/Admin Routes ---
router.post('/', assignments_controller_1.assignmentsController.createAssignment);
router.get('/course/:courseId', assignments_controller_1.assignmentsController.getCourseAssignments);
router.get('/course/:courseId/report', assignments_controller_1.assignmentsController.getCourseAssignmentReport);
router.get('/:assignmentId/submissions', assignments_controller_1.assignmentsController.getAssignmentSubmissions);
router.put('/submission/:submissionId/grade', assignments_controller_1.assignmentsController.gradeSubmission);
// --- Student Routes ---
router.get('/student/:studentId', assignments_controller_1.assignmentsController.getStudentAssignments);
const upload_middleware_1 = __importDefault(require("../middleware/upload.middleware"));
router.post('/submit', assignments_controller_1.assignmentsController.submitAssignment);
// Route for file uploads
router.post('/upload', upload_middleware_1.default.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded' });
    }
    // Return the static URL path of the file
    const fileUrl = `/uploads/${req.file.filename}`;
    res.status(200).json({ fileUrl });
});
exports.default = router;
