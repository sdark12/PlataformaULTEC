"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAuditLogs = void 0;
const insforge_1 = __importDefault(require("../config/insforge"));
const getAuditLogs = async (req, res) => {
    const branchId = req.currentUser?.branch_id;
    const db = req.dbUserClient || insforge_1.default;
    try {
        let query = db
            .from('audit_logs')
            .select(`
                *,
                user:profiles!user_id(id, full_name, email, role),
                branch:branches!branch_id(id, name)
            `)
            .order('created_at', { ascending: false })
            .limit(100);
        // If the user is attached to a branch, only fetch logs for that branch
        // For Superadmin (usually branch_id is null or handled globally), skip the eq check
        if (branchId) {
            query = query.eq('branch_id', branchId);
        }
        const { data, error } = await query;
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error('CRITICAL ERROR in getAuditLogs:', error);
        res.status(500).json({
            message: 'Error retrieving audit logs',
            error: error?.message || 'Unknown error'
        });
    }
};
exports.getAuditLogs = getAuditLogs;
