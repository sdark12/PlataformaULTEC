"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminResetPasswordSchema = exports.loginSchema = void 0;
const zod_1 = require("zod");
exports.loginSchema = zod_1.z.object({
    body: zod_1.z.object({
        email: zod_1.z.string().min(5, "El nombre de usuario/correo electrónico es muy corto."),
        password: zod_1.z.string().min(6, "La contraseña debe tener al menos 6 caracteres."),
    }),
});
exports.adminResetPasswordSchema = zod_1.z.object({
    body: zod_1.z.object({
        userId: zod_1.z.string().uuid("ID de usuario inválido."),
        newPassword: zod_1.z.string().min(6, "La nueva contraseña debe tener al menos 6 caracteres."),
    }),
});
