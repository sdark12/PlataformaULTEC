"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const auth_middleware_1 = require("../middleware/auth.middleware");
const subgrades_controller_1 = require("../controllers/subgrades.controller");
const router = (0, express_1.Router)();
// Category Routes
router.get('/subgrades/categories', auth_middleware_1.requireAuth, subgrades_controller_1.getSubgradeCategories);
router.post('/subgrades/categories', auth_middleware_1.requireAuth, subgrades_controller_1.saveSubgradeCategories);
router.delete('/subgrades/categories/:category_id', auth_middleware_1.requireAuth, subgrades_controller_1.deleteSubgradeCategory);
// Note Routes
router.get('/subgrades', auth_middleware_1.requireAuth, subgrades_controller_1.getSubgrades);
router.post('/subgrades', auth_middleware_1.requireAuth, subgrades_controller_1.saveSubgrades);
exports.default = router;
