"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateStudentSchema = exports.createStudentSchema = exports.createCourseScheduleSchema = exports.updateCourseSchema = exports.createCourseSchema = void 0;
const zod_1 = require("zod");
exports.createCourseSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z.string().min(3, "El nombre del curso debe tener al menos 3 caracteres."),
        description: zod_1.z.string().optional().nullable(),
        monthly_fee: zod_1.z.coerce.number().min(0, "La mensualidad no puede ser negativa."),
        start_date: zod_1.z.string().optional().nullable(),
        end_date: zod_1.z.string().optional().nullable(),
        branch_id: zod_1.z.string().uuid("ID de sede inválido").optional().nullable().or(zod_1.z.literal('')),
    }),
});
exports.updateCourseSchema = zod_1.z.object({
    body: zod_1.z.object({
        name: zod_1.z.string().min(3, "El nombre del curso debe tener al menos 3 caracteres.").optional(),
        description: zod_1.z.string().optional().nullable(),
        monthly_fee: zod_1.z.coerce.number().min(0, "La mensualidad no puede ser negativa.").optional(),
        is_active: zod_1.z.boolean().optional(),
        start_date: zod_1.z.string().optional().nullable(),
        end_date: zod_1.z.string().optional().nullable(),
    }),
});
exports.createCourseScheduleSchema = zod_1.z.object({
    body: zod_1.z.object({
        grade: zod_1.z.string().min(1, "El grado/sección es requerido."),
        day_of_week: zod_1.z.string().min(1, "El día de la semana es requerido."),
        start_time: zod_1.z.string().regex(/^([01]\d|2[0-3]):?([0-5]\d)$/, "Hora de inicio inválida (HH:MM)."),
        end_time: zod_1.z.string().regex(/^([01]\d|2[0-3]):?([0-5]\d)$/, "Hora de fin inválida (HH:MM)."),
    }),
});
exports.createStudentSchema = zod_1.z.object({
    body: zod_1.z.object({
        full_name: zod_1.z.string().min(3, "El nombre completo debe tener al menos 3 caracteres."),
        birth_date: zod_1.z.string().optional().nullable(),
        gender: zod_1.z.string().optional().nullable(),
        identification_document: zod_1.z.string().optional().nullable(),
        nationality: zod_1.z.string().optional().nullable(),
        address: zod_1.z.string().optional().nullable(),
        phone: zod_1.z.string().optional().nullable(),
        guardian_name: zod_1.z.string().optional().nullable(),
        guardian_phone: zod_1.z.string().optional().nullable(),
        guardian_email: zod_1.z.string().optional().nullable(),
        guardian_relationship: zod_1.z.string().optional().nullable(),
        emergency_contact_name: zod_1.z.string().optional().nullable(),
        emergency_contact_phone: zod_1.z.string().optional().nullable(),
        medical_notes: zod_1.z.string().optional().nullable(),
        previous_school: zod_1.z.string().optional().nullable(),
        personal_code: zod_1.z.string().optional().nullable(),
        user_id: zod_1.z.string().uuid("ID de usuario inválido").optional().nullable().or(zod_1.z.literal('')),
        branch_id: zod_1.z.string().uuid("ID de sede inválido").optional().nullable().or(zod_1.z.literal('')),
    }),
});
exports.updateStudentSchema = zod_1.z.object({
    body: zod_1.z.object({
        full_name: zod_1.z.string().min(3).optional(),
        birth_date: zod_1.z.string().optional().nullable(),
        gender: zod_1.z.string().optional().nullable(),
        identification_document: zod_1.z.string().optional().nullable(),
        nationality: zod_1.z.string().optional().nullable(),
        address: zod_1.z.string().optional().nullable(),
        phone: zod_1.z.string().optional().nullable(),
        guardian_name: zod_1.z.string().optional().nullable(),
        guardian_phone: zod_1.z.string().optional().nullable(),
        guardian_email: zod_1.z.string().optional().nullable(),
        guardian_relationship: zod_1.z.string().optional().nullable(),
        emergency_contact_name: zod_1.z.string().optional().nullable(),
        emergency_contact_phone: zod_1.z.string().optional().nullable(),
        medical_notes: zod_1.z.string().optional().nullable(),
        previous_school: zod_1.z.string().optional().nullable(),
        personal_code: zod_1.z.string().optional().nullable(),
        user_id: zod_1.z.string().uuid("ID de usuario inválido").optional().nullable().or(zod_1.z.literal('')),
    }),
});
