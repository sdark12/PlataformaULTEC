"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminClient = void 0;
const supabase_js_1 = require("@supabase/supabase-js");
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
if (!process.env.INSFORGE_URL || !process.env.INSFORGE_API_KEY) {
    console.error('FATAL: INSFORGE_URL and INSFORGE_API_KEY environment variables are required.');
    process.exit(1);
}
const client = (0, supabase_js_1.createClient)(process.env.INSFORGE_URL, process.env.INSFORGE_ANON_KEY || process.env.INSFORGE_API_KEY);
exports.adminClient = (0, supabase_js_1.createClient)(process.env.INSFORGE_URL, process.env.INSFORGE_SERVICE_ROLE_KEY || process.env.INSFORGE_MASTER_KEY || process.env.INSFORGE_API_KEY);
exports.default = client;
