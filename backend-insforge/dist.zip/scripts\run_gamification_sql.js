"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const pg_1 = require("pg");
const dotenv_1 = __importDefault(require("dotenv"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
dotenv_1.default.config({ path: path_1.default.join(__dirname, '../../.env') });
async function runSQL() {
    const sqlPath = path_1.default.join(__dirname, '../../create_gamification_tables.sql');
    let sql = fs_1.default.readFileSync(sqlPath, 'utf8');
    // Add grants and reload schema cache at the end
    sql += `
-- GRANTS FOR REST API
GRANT ALL ON TABLE rewards TO authenticated;
GRANT ALL ON TABLE rewards TO anon;
GRANT ALL ON TABLE rewards TO postgres;

GRANT ALL ON TABLE merit_transactions TO authenticated;
GRANT ALL ON TABLE merit_transactions TO anon;
GRANT ALL ON TABLE merit_transactions TO postgres;

-- RELOAD SCHEMA CACHE
NOTIFY pgrst, 'reload schema';
`;
    const client = new pg_1.Client({
        user: process.env.DB_USER,
        host: process.env.DB_HOST,
        database: process.env.DB_NAME,
        password: process.env.DB_PASSWORD,
        port: parseInt(process.env.DB_PORT || '5432'),
        ssl: { rejectUnauthorized: false }
    });
    try {
        await client.connect();
        console.log('Connected to Insforge Database!');
        console.log('Running Gamification SQL...');
        await client.query(sql);
        console.log('SQL Executed Successfully! Rewards and Merit tables are ready, and schema cache reloaded.');
    }
    catch (error) {
        console.error('Error executing SQL:', error);
    }
    finally {
        await client.end();
        console.log('Database connection closed.');
    }
}
runSQL();
