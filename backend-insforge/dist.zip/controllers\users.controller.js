"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteUser = exports.updateUser = exports.getUserById = exports.createUser = exports.getUsers = void 0;
const insforge_1 = __importDefault(require("../config/insforge"));
const supabase_js_1 = require("@supabase/supabase-js");
const email_service_1 = require("../services/email.service");
const getUsers = async (req, res) => {
    try {
        let query = insforge_1.default
            .from('profiles')
            .select('*', { count: 'exact' })
            .order('full_name', { ascending: true });
        const { page, limit, search, role } = req.query;
        if (role && role !== 'all') {
            query = query.eq('role', role);
        }
        if (search) {
            query = query.or(`full_name.ilike.%${search}%,email.ilike.%${search}%`);
        }
        if (page && limit) {
            const pageNum = parseInt(page, 10);
            const limitNum = parseInt(limit, 10);
            const offset = (pageNum - 1) * limitNum;
            query = query.range(offset, offset + limitNum - 1);
            const { data, error, count } = await query;
            if (error)
                throw error;
            return res.json({
                data,
                meta: {
                    total: count || 0,
                    page: pageNum,
                    limit: limitNum,
                    totalPages: Math.ceil((count || 0) / limitNum)
                }
            });
        }
        const { data, error } = await query;
        if (error)
            throw error;
        res.json(data);
    }
    catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ message: 'Error fetching users' });
    }
};
exports.getUsers = getUsers;
const createUser = async (req, res) => {
    try {
        const { email, password, full_name, role, phone, student_id, branch_id } = req.body;
        // Use a temporary client for signup to avoid overriding the backend's global session
        const tempClient = (0, supabase_js_1.createClient)(process.env.INSFORGE_URL || 'https://w6x267sp.us-east.insforge.app', process.env.INSFORGE_API_KEY || process.env.INSFORGE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3OC0xMjM0LTU2NzgtOTBhYi1jZGVmMTIzNDU2NzgiLCJlbWFpbCI6ImFub25AaW5zZm9yZ2UuY29tIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODAxOTQ2NTJ9.LsB4ffiFE5H7qEfhgnM0NuPTX_It2aYd4iEmVUOHmh4');
        let userId;
        // Create auth user — handle "already exists" gracefully
        try {
            const { data: authData, error: authError } = await tempClient.auth.signUp({
                email,
                password
            });
            if (authError) {
                // Check if user already exists (from a previous failed attempt)
                const errorMsg = authError.message || authError.error || '';
                const errorCode = authError.error || authError.statusCode || '';
                if (errorMsg.includes('already exists') || errorCode === 'ALREADY_EXISTS' || authError.statusCode === 409) {
                    console.log(`User ${email} already exists in auth. Looking up existing profile...`);
                    // Look up user by email in profiles
                    const { data: existingByEmail } = await insforge_1.default
                        .from('profiles')
                        .select('id')
                        .eq('email', email)
                        .single();
                    if (existingByEmail) {
                        // Profile already exists — just return a friendly error
                        return res.status(409).json({ message: `El usuario con correo ${email} ya existe en el sistema.` });
                    }
                    // Auth user exists but profile doesn't (orphaned) — we need the auth user ID
                    // Use admin sign-in to find the user ID, or look it up via the admin API
                    // Since we can't easily get the ID from a failed signUp, we'll try a workaround:
                    // Sign in with the provided password to get the user ID
                    try {
                        const { data: signInData, error: signInError } = await tempClient.auth.signInWithPassword({
                            email,
                            password
                        });
                        if (signInError || !signInData?.user) {
                            // Can't sign in — maybe wrong password from previous attempt
                            // Try signing in with the new password
                            return res.status(400).json({
                                message: `El correo ${email} ya tiene credenciales registradas con una contraseña diferente. Intente con otro correo o contacte al administrador.`
                            });
                        }
                        userId = signInData.user.id;
                        console.log(`Found orphaned auth user: ${userId}. Will create profile.`);
                    }
                    catch (signInErr) {
                        return res.status(400).json({
                            message: `El correo ${email} ya existe pero no se puede acceder. Intente con otro correo.`
                        });
                    }
                }
                else {
                    throw authError;
                }
            }
            else if (!authData || !authData.user) {
                return res.status(400).json({ message: 'Error al registrar credenciales de acceso.' });
            }
            else {
                userId = authData.user.id;
            }
        }
        catch (signUpErr) {
            // Re-check if it's the "already exists" error from the SDK throwing instead of returning
            const errMsg = signUpErr?.message || '';
            if (errMsg.includes('already exists') || errMsg.includes('ALREADY_EXISTS')) {
                // Same handling as above
                const { data: existingByEmail } = await insforge_1.default
                    .from('profiles')
                    .select('id')
                    .eq('email', email)
                    .single();
                if (existingByEmail) {
                    return res.status(409).json({ message: `El usuario con correo ${email} ya existe en el sistema.` });
                }
                // Try sign in to recover the orphaned user
                try {
                    const { data: signInData, error: signInError } = await tempClient.auth.signInWithPassword({
                        email,
                        password
                    });
                    if (signInError || !signInData?.user) {
                        return res.status(400).json({
                            message: `El correo ${email} ya tiene credenciales registradas. Intente con otro correo o contacte soporte.`
                        });
                    }
                    userId = signInData.user.id;
                }
                catch {
                    return res.status(400).json({
                        message: `El correo ${email} ya existe en el sistema. Intente con otro correo.`
                    });
                }
            }
            else {
                console.error('Error creating user auth:', signUpErr);
                return res.status(500).json({ message: 'Error interno al crear credenciales.' });
            }
        }
        // Update or Insert Profile
        const { data: existingProfile } = await insforge_1.default
            .from('profiles')
            .select('id')
            .eq('id', userId)
            .single();
        const profilePayload = {
            id: userId,
            email,
            full_name,
            role
        };
        if (branch_id !== undefined)
            profilePayload.branch_id = branch_id === '' ? null : branch_id;
        let profileResult;
        if (existingProfile) {
            profileResult = await insforge_1.default
                .from('profiles')
                .update(profilePayload)
                .eq('id', userId)
                .select()
                .single();
        }
        else {
            profileResult = await insforge_1.default
                .from('profiles')
                .insert([profilePayload])
                .select()
                .single();
        }
        if (profileResult.error) {
            console.error('Profile creation error:', profileResult.error);
            return res.status(400).json({ message: 'Error al registrar el perfil.', details: profileResult.error });
        }
        // Link to student if provided
        if (role === 'student' && student_id) {
            const { error: studentLinkError } = await insforge_1.default
                .from('students')
                .update({ user_id: userId })
                .eq('id', student_id);
            if (studentLinkError) {
                console.error('Student linking error:', studentLinkError);
            }
        }
        // Send Welcome Email asynchronously
        (0, email_service_1.sendWelcomeEmail)(email, full_name, role, password);
        res.status(201).json(profileResult.data);
    }
    catch (error) {
        console.error('Error creating user:', error);
        res.status(500).json({ message: 'Error interno al crear usuario.' });
    }
};
exports.createUser = createUser;
const getUserById = async (req, res) => {
    try {
        const { id } = req.params;
        const { data, error } = await insforge_1.default
            .from('profiles')
            .select('*')
            .eq('id', id)
            .single();
        if (error)
            throw error;
        if (!data)
            return res.status(404).json({ message: 'User not found' });
        let userPhone = data.phone || null;
        if (data.role === 'student') {
            const { data: st } = await insforge_1.default.from('students').select('phone').eq('user_id', id).maybeSingle();
            if (st?.phone)
                userPhone = st.phone;
        }
        else if (data.role === 'instructor') {
            const { data: inst } = await insforge_1.default.from('instructors').select('phone').eq('user_id', id).maybeSingle();
            if (inst?.phone)
                userPhone = inst.phone;
        }
        else if (data.role === 'parent') {
            const { data: links } = await insforge_1.default
                .from('parent_student_links')
                .select('students(guardian_phone, phone)')
                .eq('parent_user_id', id);
            if (links && links.length > 0) {
                const stData = links[0]?.students;
                const linkedPhone = stData?.guardian_phone || stData?.phone;
                if (linkedPhone && !userPhone) {
                    userPhone = linkedPhone;
                }
            }
        }
        res.json({ ...data, phone: userPhone });
    }
    catch (error) {
        console.error('Error fetching user:', error);
        res.status(500).json({ message: 'Error fetching user' });
    }
};
exports.getUserById = getUserById;
const updateUser = async (req, res) => {
    try {
        const { id } = req.params;
        const { full_name, email, role, phone, active, branch_id } = req.body;
        const updatePayload = {};
        if (full_name !== undefined)
            updatePayload.full_name = full_name;
        if (email !== undefined)
            updatePayload.email = email;
        if (role !== undefined)
            updatePayload.role = role;
        if (branch_id !== undefined)
            updatePayload.branch_id = branch_id === '' ? null : branch_id;
        const { data, error } = await insforge_1.default
            .from('profiles')
            .update(updatePayload)
            .eq('id', id)
            .select('*')
            .single();
        if (error)
            throw error;
        if (!data)
            return res.status(404).json({ message: 'User not found' });
        // Update phone in specific role tables if provided
        if (phone !== undefined) {
            const currentRole = role || data.role;
            if (currentRole === 'student') {
                await insforge_1.default.from('students').update({ phone }).eq('user_id', id);
            }
            else if (currentRole === 'parent') {
                const { data: links } = await insforge_1.default
                    .from('parent_student_links')
                    .select('student_id')
                    .eq('parent_user_id', id);
                if (links && links.length > 0) {
                    const studentIds = links.map((l) => l.student_id);
                    await insforge_1.default.from('students').update({ guardian_phone: phone }).in('id', studentIds);
                }
            }
            else if (currentRole === 'instructor') {
                await insforge_1.default.from('instructors').update({ phone }).eq('user_id', id);
            }
        }
        // Handle student linking if role is student and student_id is provided
        const { student_id } = req.body;
        if (role === 'student' && student_id) {
            await insforge_1.default
                .from('students')
                .update({ user_id: null })
                .eq('user_id', id);
            const { error: studentLinkError } = await insforge_1.default
                .from('students')
                .update({ user_id: id })
                .eq('id', student_id);
            if (studentLinkError) {
                console.error('Student linking error during update:', studentLinkError);
            }
        }
        else if (role && role !== 'student') {
            await insforge_1.default
                .from('students')
                .update({ user_id: null })
                .eq('user_id', id);
        }
        res.json({ ...data, phone: phone !== undefined ? phone : undefined });
    }
    catch (error) {
        console.error('Error updating user:', error);
        res.status(500).json({ message: 'Error updating user' });
    }
};
exports.updateUser = updateUser;
// Deleting a user might require auth admin access. For now we will allow deactivating (active boolean)
const deleteUser = async (req, res) => {
    try {
        const { id } = req.params;
        // Let's assume we do a soft delete or just delete the profile record
        const { data, error } = await insforge_1.default
            .from('profiles')
            .delete()
            .eq('id', id)
            .select()
            .single();
        if (error)
            throw error;
        if (!data)
            return res.status(404).json({ message: 'User not found or already deleted' });
        res.json({ message: 'User deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({ message: 'Error deleting user' });
    }
};
exports.deleteUser = deleteUser;
